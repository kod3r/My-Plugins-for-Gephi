/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Partition;

import org.gephi.data.attributes.api.AttributeColumn;
import org.gephi.partition.api.PartitionController;
import org.gephi.partition.plugin.NodeColorTransformer;
import org.gephi.statistics.plugin.Modularity;
import org.openide.util.Lookup;

/*
 Copyright 2013 DOREMUS
 Authors : Clement Levallois <clementlevallois@gmail.com>
 Website : http://www.clementlevallois.net
*/

public class Partition {
   
//                AttributeColumn modColumn = attributeModel.getNodeTable().getColumn(Modularity.MODULARITY_CLASS);
//            PartitionController partitionController = Lookup.getDefault().lookup(PartitionController.class);
//            org.gephi.partition.api.Partition part = partitionController.buildPartition(modColumn, graph);
//
//            NodeColorTransformer nodeColorTransformer = new NodeColorTransformer();
//            nodeColorTransformer.randomizeColors(part);
//            partitionController.transform(part, nodeColorTransformer);

    
}
